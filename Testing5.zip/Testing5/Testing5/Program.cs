﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing5
{
    class Program
    {
        static void Main(string[] args)
        {
            int planetnumber;
            int earthweight;

            Console.WriteLine("           Menu of Planets");
            Console.WriteLine("           ==== == =======\n");


            Console.WriteLine("1. Jupiter   2. Mars    3. Mercury");
            Console.WriteLine("4. Neptune   5. Pluto   6. Saturn");
            Console.WriteLine("7. Uranus    8. Venus   9.<Quit>\n");


            Console.WriteLine("Enter your menu choice:");
            planetnumber = int.Parse(Console.ReadLine());

            Console.WriteLine(" ");

           Console.WriteLine("Enter your weight on Earth:");
            earthweight = int.Parse(Console.ReadLine());

            Console.WriteLine(" ");

            Console.WriteLine("Your weight on your choosen planet is:");

           double[] planetchoice = new double[10] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
           double[] weight = new double[10] { 0.00, 0.37, 0.88, 0.38, 2.64, 1.15, 1.15, 1.12, 0.04, 0.00 };

           Console.WriteLine(weight[planetnumber] * earthweight);

            Console.WriteLine(" ");


        }
        //  string planets;
        //  string[] planets = new string[10] { " ", "Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto" };

        //Your weight of "weight" pounds on Earth would be "results" pounds on "planets"
        // x*y
        //Console.WriteLine(weight[2] * 120);}
        // convert user input into x and y
        //Console.WriteLine(weight[x] * y);}
    }





}

